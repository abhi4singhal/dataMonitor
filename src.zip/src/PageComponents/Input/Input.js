import React from 'react';

class Input extends React.Component{
  render(){
    return(
      <div>
        <h3>Input</h3>
      </div>
    )
  }
}

export default Input;
