import React, { Component } from 'react';
// import { Router, Link, IndexRoute } from 'react-router';
// import { BrowserRouter as Router, Link} from 'react-router-dom';
// import { Provider } from 'react-redux';
// import './App.css';
import AppContainer from './AppContainer';

class App extends Component {
  render() {
    return (
      <AppContainer></AppContainer>
    );
  }
}

export default App;
